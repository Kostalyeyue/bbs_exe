from django.apps import AppConfig


class MybbsConfig(AppConfig):
    name = 'mybbs'
