

dic={'name':'lqz'}

dic['name']=000
print(dic)